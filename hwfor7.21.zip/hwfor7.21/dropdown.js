function dropDown() {
  document.getElementById("myDropdown").classList.toggle("show");
}